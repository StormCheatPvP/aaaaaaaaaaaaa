# PASSO A PASSO PARA CONFIGURAR A SOURCE

1) Entre no arquivo config.json e config.js e coloque as informações que está pedindo entre as aspas, e os valores que estão vazios não precisa preencher nada, você pode configurar por comando quando o bot ligar.

2) Entre no arquivo donoadd.js na pasta SlashCommandse substituia meu ID pelo ID do dono

3) Se estiver no VSCode ou qualquer outra IDE, digite npm i para instalar todas as dependências necessárias do bot.

4) Depois, digite node . para ligar o bot direto na sua máquina. Você pode configurar e hospedar diretamente se quiser, sem precisar instalar as dependências.

# PASSO A PASSO PARA CONFIGURAR A config.js
1) botClientID: "", coloque id em bot 
2) botPrefix: "/", não mexa bot prefix claro quiser mudar prefix
3) owner: "",
    ownerID: "",
    embedColor: "#9600ff",

# PASSO A PASSO PARA CONFIGURAR A config.js
1) "access_token": "", 
1) "prefix": "/",
1) "owner": "devvictoria",
1) "logs": "1186533972050710608",
1) "logs_staff": "1186533994477649950",
1) "category": "1186534049553055784",
1) "title": "Foxy Store",
1) "color": "#9600ff",
1) "banner": "",
1) "thumbnail": "",
1) "role": "1186534672684032010"