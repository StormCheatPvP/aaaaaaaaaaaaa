module.exports = {
    botClientID: "",
    botPrefix: "/",
    owner: "",
    ownerID: "",
    embedColor: "#9600ff",
    
  }

const Discord = require("discord.js")